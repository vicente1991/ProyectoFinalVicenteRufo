package com.salesianostriana.dam.proyecto.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.salesianostriana.dam.proyecto.modelo.Perrera;
import com.salesianostriana.dam.proyecto.repository.PerreraRepository;

@Service
public class PerreraServicios {

	@Autowired
	private PerreraRepository repositorio;
	/**
	 * Este metodo muestra a todos en una lista de perreras
	 * @return
	 */
	public List<Perrera> findAll() {
		return repositorio.findAll();
	}	
	/**
	 * Este metodo busca en una lista de perreras las destacadas
	 * @return
	 */
	public List<Perrera> findDestacadas() {
		return repositorio.findDestacadas();
	}
	/**
	 * Este metodo guarda una perrera nueva
	 * @param perrera
	 * @return
	 */
	public Perrera save(Perrera perrera) {
		return repositorio.save(perrera);
	}
	/**
	 * Este metodo busca a traves de la id
	 * @param id
	 * @return
	 */
	public Perrera findById(Long id) {
		return repositorio.findById(id).orElse(null);
	}
	/**
	 * Este metodo borra una perrera
	 * @param perrera
	 * @return
	 */
	public Perrera delete(Perrera perrera) {
		Perrera result = findById(perrera.getId());
		repositorio.delete(result);
		return result;
	}
	
	/**
	 * Este metodo borra por id
	 * @param id
	 */
	public void deleteById(Long id) {
		repositorio.deleteById(id);
	}
}
