package com.salesianostriana.dam.proyecto.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.salesianostriana.dam.proyecto.modelo.Animal;
import com.salesianostriana.dam.proyecto.servicios.AnimalServicios;
import com.salesianostriana.dam.proyecto.servicios.PerreraServicios;

@Controller
public class MainController {

	private static final int NUM_ANIMALES_ALEATORIOS = 3;
	
	@Autowired
	private PerreraServicios perreraService;
	
	@Autowired
	private AnimalServicios animalService;
	
	@GetMapping("/")
	public String index(@RequestParam(name="idPerrera",required = false) Long idPerrera,Model model) {
		model.addAttribute("perreras",perreraService.findAll());
		List<Animal> animales;
		
		if( idPerrera == null) {
			animales = animalService.obtenerAnimalesAleatorios(NUM_ANIMALES_ALEATORIOS);
		} else {
			animales = animalService.findAllByPerrera(idPerrera);
		}
		model.addAttribute("animales",animales);
		return "Arca";
	}
}
