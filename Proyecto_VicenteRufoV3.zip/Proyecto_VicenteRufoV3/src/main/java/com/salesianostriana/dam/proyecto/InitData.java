package com.salesianostriana.dam.proyecto;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.salesianostriana.dam.proyecto.modelo.Perrera;
import com.salesianostriana.dam.proyecto.servicios.PerreraServicios;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class InitData {
	
	
	private final PerreraServicios perreraService;
	/**
	 * Este metodo sirve para crear perreras ya definidas dentro de la entidad Perrera
	 */
	@PostConstruct
	public void Init() {
		
		List <Perrera> guardarPerrera= List.of(new Perrera("Sevilla",true,null), new Perrera("Huelva",false,null));
		
		for (Perrera perrera : guardarPerrera) {
			perreraService.save(perrera);
		}
	}
	

}
