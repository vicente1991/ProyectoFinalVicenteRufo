package com.salesianostriana.dam.proyecto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.salesianostriana.dam.proyecto.modelo.Animal;
import com.salesianostriana.dam.proyecto.servicios.AnimalServicios;
import com.salesianostriana.dam.proyecto.servicios.PerreraServicios;


@Controller
@RequestMapping("/admin/animal")
public class AnimalController {

	@Autowired
	private AnimalServicios animalService;
	
	@Autowired
	private PerreraServicios perreraService;
	
	@GetMapping("/")
	public String index (Model model) {
		model.addAttribute("animales",animalService.findAll());
		return "admin/list-animal";
	}
	@GetMapping("/nuevo")
	public String nuevoAnimal(Model model) {
		model.addAttribute("animal", new Animal());
		return "admin/form-animal";
	}
	@PostMapping("/nuevo/submit")
	public String submitNuevoAnimal(Animal animal,Model model) {
		animalService.save(animal);
		return "redirect:/admin/animal/";
	}
	
	@GetMapping("edit/{id}")
	public String editarAnimal(@PathVariable("id") Long id, Model model) {
		Animal animal= animalService.findById(id);
		
		if(animal != null) {
			model.addAttribute("animal",animal);
			model.addAttribute("perreras", perreraService.findAll());
			return "admin/form-animal";
		}else {
			return "redirect:/admin/animal/";
		}	
	}
	@GetMapping("/borrar{id}")
	public String borrarAnimal(@PathVariable("id") Long id, Model model) {
		Animal animal = animalService.findById(id);
		
		if(animal != null) {
			animalService.delete(animal);
		}
		return "redirect:/admin/animal/";
	}
	
	
	@GetMapping("borrar/{id}")
	public String removeAnimal(@PathVariable("id") Long id, Model model) {
		/*Animal animal= animalService.findById(id);
		
		if(animal != null) {
			model.addAttribute("animal",animal);
			model.addAttribute("perreras", perreraService.findAll());
			return "admin/form-animal";
		}else {
			return "redirect:/admin/animal/";
		}*/
		
		animalService.deleteById(id);
		return "redirect:/admin/animal/";
		
	}
}
