package com.salesianostriana.dam.proyecto.modelo;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity @Data @NoArgsConstructor @AllArgsConstructor
public class Animal {

	@Id
	@GeneratedValue
	private Long id;
	
	private String nombre;
	
	@Lob
	private String imagen;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate fechaNac;
	
	private String raza;
	
	@ManyToOne
	private Perrera perrera;

	public Animal(String nombre, String imagen, LocalDate fechaNac, String raza, Perrera perrera) {
		super();
		this.nombre = nombre;
		this.imagen = imagen;
		this.fechaNac = fechaNac;
		this.raza = raza;
		this.perrera = perrera;
	}

	

	
	

	
	
	
}
