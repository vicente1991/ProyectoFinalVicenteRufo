package com.salesianostriana.dam.proyecto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.salesianostriana.dam.proyecto.modelo.Perrera;

public interface PerreraRepository extends JpaRepository<Perrera, Long>{

	@Query("select p from Perrera p where p.destacada = true")
	public List<Perrera> findDestacadas();
}
