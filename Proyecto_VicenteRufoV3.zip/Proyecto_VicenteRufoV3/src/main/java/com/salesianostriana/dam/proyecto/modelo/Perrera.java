package com.salesianostriana.dam.proyecto.modelo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity @Data @NoArgsConstructor @AllArgsConstructor
public class Perrera {
	
	@Id
	@GeneratedValue
	private Long id;
	
	private String nombre;
	
	private boolean destacada;
	
	@Lob
	private String imagen;

	@ToString.Exclude
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy = "perrera",fetch = FetchType.EAGER)
	private List<Animal> animales= new ArrayList<>();

	
	public Perrera(String nombre, boolean destacada, String imagen) {
		super();
		this.nombre = nombre;
		this.destacada = destacada;
		this.imagen = imagen;
	}
	
	

}
