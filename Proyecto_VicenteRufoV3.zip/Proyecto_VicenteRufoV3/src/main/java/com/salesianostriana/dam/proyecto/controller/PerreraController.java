package com.salesianostriana.dam.proyecto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.salesianostriana.dam.proyecto.modelo.Perrera;
import com.salesianostriana.dam.proyecto.servicios.PerreraServicios;

@Controller
@RequestMapping("/admin/perrera")
public class PerreraController {

	
	@Autowired
	private PerreraServicios perreraService;
	
	
	@GetMapping("/")
	public String index(Model model) {
		model.addAttribute("perreras", perreraService.findAll());
		return "admin/list-perrera";
	}
	
	@GetMapping("/nueva")
	public String nuevaPerrera(Model model) {
		model.addAttribute("perrera",new Perrera());
		return "admin/form-perrera";
	}
	
	@PostMapping("/nueva/submit")
	public String submitNuevaPerrera(@ModelAttribute("perrera") Perrera perrera,Model model ) {
		perreraService.save(perrera);
		return "redirect:/admin/perrera/";
	}
	
	@GetMapping("/editar/{id}")
	public String editarPerrera(@PathVariable("id") Long id,Model model) {
		Perrera perrera = perreraService.findById(id);
		
		if(perrera != null) {
			model.addAttribute("perrera",perrera);
			return "admin/form-perrera";
		}else {
			return "redirect:/admin/perrera/";
		}
	}
	
	@GetMapping("/borrar/{id}")
	public String borrarPerrera(@PathVariable("id") Long id, Model model) {
		
		/*if(perrera != null) {
			if(animalService.numeroProductosCategoria(perrera)==0) {
				perreraService.delete(perrera);
			}else {
				return "redirect:/admin/perrera/?error=true";
			}
		}
		return "redirect:/admin/perrera/";*/
		perreraService.deleteById(id);
		return "redirect:/admin/perrera/";
	}
}
