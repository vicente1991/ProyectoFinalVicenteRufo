package com.salesianostriana.dam.proyecto.servicios;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.salesianostriana.dam.proyecto.modelo.Animal;
import com.salesianostriana.dam.proyecto.modelo.Perrera;
import com.salesianostriana.dam.proyecto.repository.AnimalRepository;

@Service
public class AnimalServicios {

	
	@Autowired
	private AnimalRepository repositorio;
	/**
	 * Este metodo busca en la lista de animales y muestra a todos los que hay dentro
	 * @return
	 */
	public List<Animal> findAll() {
		return repositorio.findAll();
	}
	
	/**
	 * Este metodo busca animales dentro de una perrera  
	 * @param perrera
	 * @return
	 */
	public List<Animal> findAllByPerrera(Perrera perrera) {
		return repositorio.findByPerrera(perrera);
	}
	/**
	 * Este metodo busca en la lista a traves del id de la perrera
	 * @param perreraId
	 * @return
	 */
	public List<Animal> findAllByPerrera(Long perreraId) {
		return repositorio.findByPerreraId(perreraId);
	}
	/**
	 * Este metodo busca un animal por id
	 * @param id
	 * @return
	 */
	public Animal findById(Long id) {
		return repositorio.findById(id).orElse(null);
	}
	/**
	 * Este metodo guarda un nuevo animal
	 * @param animal
	 * @return
	 */
	public Animal save(Animal animal) {
		return repositorio.save(animal);
	}
	/**
	 * Este metodo borra a un animal 
	 * @param animal
	 * @return
	 */
	public Animal delete(Animal animal) {
		Animal result = findById(animal.getId());
		repositorio.delete(result);
		return result;
	}
	/**
	 * Este metodo busca por numero de animales pasandole una perrera
	 * @param perrera
	 * @return
	 */
	public int numeroAnimalPerrera(Perrera perrera) {
		return repositorio.findNumAnimalPerrera(perrera);
	}
	/**
	 * Este metodo sirve para obtener un numero aleatorio de animales
	 * @param numero
	 * @return
	 */
	public List<Animal> obtenerAnimalesAleatorios(int numero) {
		List<Long> listaIds = repositorio.obtenerIds();
		Collections.shuffle(listaIds);
		listaIds = listaIds.stream().limit(numero).collect(Collectors.toList());
		return repositorio.findAllById(listaIds);

	}
	/**
	 * Este metodo borra por id a un animal
	 * @param id
	 */
	public void deleteById(Long id) {
		repositorio.deleteById(id);
	}
}
