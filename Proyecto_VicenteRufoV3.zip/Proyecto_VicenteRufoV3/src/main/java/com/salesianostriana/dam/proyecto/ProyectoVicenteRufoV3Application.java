package com.salesianostriana.dam.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoVicenteRufoV3Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoVicenteRufoV3Application.class, args);
	}

}
