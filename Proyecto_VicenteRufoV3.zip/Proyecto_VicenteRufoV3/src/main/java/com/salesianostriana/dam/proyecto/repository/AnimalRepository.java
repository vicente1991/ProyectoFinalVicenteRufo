package com.salesianostriana.dam.proyecto.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.salesianostriana.dam.proyecto.modelo.Animal;
import com.salesianostriana.dam.proyecto.modelo.Perrera;

public interface AnimalRepository extends JpaRepository<Animal, Long>{
	
	public List<Animal> findByPerrera(Perrera perrera);
	
	@Query("select a.id from Animal a")
	public List<Long> obtenerIds();
	
	@Query("select a from Animal a where a.perrera.id = ?1")
	public List<Animal> findByPerreraId(Long perreraId);
	
	@Query("select count(a) from Animal a where a.perrera = ?1")
	public int findNumAnimalPerrera(Perrera perrera);
}
