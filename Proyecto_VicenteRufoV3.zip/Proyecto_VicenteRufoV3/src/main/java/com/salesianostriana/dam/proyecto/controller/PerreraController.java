package com.salesianostriana.dam.proyecto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.salesianostriana.dam.proyecto.modelo.Perrera;
import com.salesianostriana.dam.proyecto.servicios.AnimalServicios;
import com.salesianostriana.dam.proyecto.servicios.PerreraServicios;

@Controller
@RequestMapping("/admin/perrera")
public class PerreraController {

	
	@Autowired
	private PerreraServicios perreraService;
	
	@Autowired
	private AnimalServicios animalService;
	
	
	
	/**
	 * Este metodo muestra la lista de perreras existentes
	 * @param model
	 * @return
	 */
	@GetMapping("/")
	public String index(Model model) {
		model.addAttribute("perreras", perreraService.findAll());
		return "admin/list-perrera";
	}
	/**
	 * Este metodo crea una nueva perrera
	 * @param model
	 * @return
	 */
	@GetMapping("/nueva")
	public String nuevaPerrera(Model model) {
		model.addAttribute("perrera",new Perrera());
		return "admin/form-perrera";
	}
	/**
	 * Este netodo añade una nueva perrera y te devuelve a la lista de perreras totatles
	 * @param perrera
	 * @param model
	 * @return
	 */
	@PostMapping("/nueva/submit")
	public String submitNuevaPerrera(@ModelAttribute("perrera") Perrera perrera,Model model ) {
		perreraService.save(perrera);
		return "redirect:/admin/perrera/";
	}
	/**
	 * Este metodo edita una perrera a traves de su id
	 * @param id
	 * @param model
	 * @return
	 */
	@GetMapping("/editar/{id}")
	public String editarPerrera(@PathVariable("id") Long id,Model model) {
		Perrera perrera = perreraService.findById(id);
		
		if(perrera != null) {
			model.addAttribute("perrera",perrera);
			return "admin/form-perrera";
		}else {
			return "redirect:/admin/perrera/";
		}
	}
	/**
	 * Este metodo borra una perrera
	 * @param id
	 * @param model
	 * @return
	 */
	
	@GetMapping("/borrar/{id}")
	public String borrarPerrera(@PathVariable("id") Long id, Model model) {
		Perrera perrera = perreraService.findById(id);
	
	
	if (perrera != null) {
		
		if (animalService.numeroAnimalPerrera(perrera) == 0) {
			perreraService.delete(perrera);				
		} else {
				
			return "redirect:/admin/perrera/?error=true";
		}
		
	} 

	return "redirect:/admin/perrera/";
	}
	
	@GetMapping("/borrar{id}")
	public String removePerrera(@PathVariable("id") Long id, Model model) {
		
		perreraService.deleteById(id);
		return "redirect:/admin/perrera/";
	}
}
