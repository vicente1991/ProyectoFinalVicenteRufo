package com.salesianostriana.dam.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoVicenteRufoV3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
